<?php 
    session_start();
    $vardas = $_SESSION['admin'];
    if($_SESSION['admin'] == NULL) {
        header('Location: http://localhost:8888/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
?>
<script type="text/javascript"> 
    function closeWin()
    {
        link = 'items.php';
        window.location.href = link;
    }
</script>
<?php
    $link = mysqli_connect("localhost", "mamp", "", "packetup");
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    $ItemName = $_POST['ItemName'];
    $ItemCount = $_POST['ItemCount'];
    $BarCode = $_POST['BarCode'];
    $sql = "INSERT INTO items (status,item_name,BarCode,item_type,item_count,SHELF,ROW,SEGMENT) VALUES('1','$ItemName','$BarCode',NULL,'$ItemCount',NULL,NULL,NULL)";
    $query3 = mysqli_query($link, "INSERT INTO logs (state, datetime, item, BarCode, text, user) VALUES ('new item',CURRENT_TIMESTAMP,'$ItemName','$BarCode' , 'New Item in warehouse. +$ItemCount','$vardas')");
    if(mysqli_query($link, $sql)){
        echo "Records inserted successfully. <SCRIPT LANGUAGE='javascript'>closeWin();</SCRIPT>";
    }else{
        echo "New item insert failed! </br> Reason: " . mysqli_error($link);
    }
    mysqli_close($link);
?>



