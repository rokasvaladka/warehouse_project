<?php 
    session_start();
    if($_SESSION['admin'] == NULL) {
    header('Location: http://localhost:8888/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
    include('connect.php');
    include('top_menu.php');
    include('left_menu.php');
?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="jquery/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="jquery/css/bootstrap.css"/>
<html lang="<?php echo $language; ?>">
<head>
</head>
<body >
    <img src='img/packetup_logo.png' style='padding-left: 50px;'/><br/><br/>
    <?php
        $sql = "SELECT items.item_name, items.item_count, types.type_name , items.BarCode FROM items LEFT JOIN types ON items.item_type = types.ID WHERE status = '1' ORDER BY item_name ASC;";
        $result = $conn->query($sql);
    ?>
    <div id='body'>
        <div style='display:none'>
            <?php
                $item_list = array();
                if ($result->num_rows > 0) {
                    $item_list = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    print_r ($item_list);
                } 
            ?>
        </div>
        <div class="table" id="hideifnone">
            <h2>ITEM LIST</h2><br><br>
            <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Enter items name" title="Items name">
            <input type="text" id="myInput2" onkeyup="myFunction2()" placeholder="Scan barcode here" title="Barcode" ><br></br>
            <table border='1' id="myTable" class="sortable">
                <tr>
                    <th><h4><center>Item name</center></h4></th>
                    <th><h4><center>Barcode</center></h4></th>
                    <th><h4><center>Item count</center></h4></th>
                </tr>
                <?php
                    foreach($item_list as $item) {
                        echo '<tr>';
                        echo '<td>' .$item['item_name']. ' </td>';
                        echo '<td><center> '.$item['BarCode'].' </center></td>';
                        echo '<td><center> ' .$item['item_count']. ' </center></td>';
                        echo '</tr>';
                    }
                ?>
            </table>
        </div>
    </div>
    <script>
        function myFunction() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[0];
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    }
                    else {
                        tr[i].style.display = "none";
                    }
                }       
            }
        }
        function myFunction2() {
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("myInput2");
                filter = input.value.toUpperCase();
                table = document.getElementById("myTable");
                tr = table.getElementsByTagName("tr");
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[1];
                        if (td) {
                            txtValue = td.textContent || td.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        }
                        else {
                            tr[i].style.display = "none";
                        }
                    }       
                }
            }
    </script>
</body>
</html>