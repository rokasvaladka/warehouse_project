<?php
    $sname = "localhost";
    $unmae = "mamp";
    $password = "";
    $db_name = "packetup";
    $conn = mysqli_connect($sname, $unmae, $password, $db_name);
    if (!$conn){
        echo "Connection failed!";
    }
?>