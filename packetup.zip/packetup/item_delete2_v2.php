<?php 
    session_start();
    $vardas = $_SESSION['admin'];
    if($_SESSION['admin'] == NULL) {
        header('Location: http://localhost:8888/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
?>
<script type="text/javascript"> 
    function closeWin(){
        link = 'items.php';
        window.location.href = link;
    }
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="jquery/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="jquery/css/bootstrap.css"/>
</head>
<body>
    <img src='img/packetup_logo.png' style='padding-left: 50px;'/><br/><br/>
    <?php
        include 'connect.php';
        include 'top_menu.php';
        include 'left_menu.php';
        $BarCode = $_POST['BarCode'];
        $conn = mysqli_connect("localhost", "mamp", "", "packetup");
    ?>
    <div id='body'>
        <h2>EDIT COUNT</h2>
        <?php
            $sql = "SELECT item_name, item_count, BarCode
            FROM items 
            WHERE status = '1' AND BarCode=$BarCode
            ";
            $result = $conn->query($sql);
        ?>
        <div style='display:none'>
            <?php
                $item_list = array();
                if ($result->num_rows > 0) {
                    $item_list = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    print_r ($item_list);
                }
            ?>
        </div>
        <h1>ITEM SELECTED</h1>
        <table border='1'>
            <tr>
                <th>-Item name-</th>
                <th> Barcode </th>
                <th> Count </th>
            </tr>
            <?php
            foreach($item_list as $item) {
                echo '<tr>';
                echo '<td>'.$item['item_name']. '</td>';
                echo '<td>'.$item['BarCode']. '</td>';
                echo '<td><center>'.$item['item_count'].'</center></td>';
                echo '</tr>';
            }
            ?>
        </table>
        <form action='item_delete_do_v2.php' method='POST' style='width:400px;'>
        <div>
            <table   cellspacing='0'>
            <tr>
                <td>
                    <label for="itemcount">You are about to delete this item, ARE YOU SURE?</label><br>
                </td>
                <td></td>
            </tr></br>
            <?php 
                $sql = "SELECT item_name
                FROM items 
                WHERE status = '1' AND BarCode=$BarCode
                ";
                $result = $conn->query($sql);
                $itemai = array();
                if ($result->num_rows > 0) {
                    $itemai = mysqli_fetch_all($result, MYSQLI_ASSOC);
                }
                foreach($itemai as $itemas) {
                    echo '<input type="hidden" name="itemas" value="'.$item["item_name"].'"/>';
                    echo '<input type="hidden" name="barkodas" value="'.$item["BarCode"].'"/>';
                }
            ?>
            </table>
        </div>
        <input name='ItemDeletev2' value='DELETE' type='submit' class='btn btn-primary' onclick="alert( 'Item is now deleted.' )"/>
    
        
        </form>
    </div>
</body>
</html>
