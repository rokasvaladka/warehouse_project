<?php 
    session_start();
    if($_SESSION['admin'] == NULL) {
        header('Location: http://localhost:8888/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <script src="jquery/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="jquery/css/bootstrap.css"/>
</head>
<body>
    <img src='img/packetup_logo.png' style='padding-left: 50px;'/><br/><br/>
    <?php
        include 'connect.php';
        include 'top_menu.php';
        include 'left_menu.php';
    ?>
    <div id='body'>
        <h2>ADD NEW ITEM</h2><br><br>
        <form action='item_add_do.php' method='POST' >
            <div>
                <table   cellspacing='0'>
                    <tr>
                        <td>
                            <label for="itemname">Item Name</label><br>
                        </td>
                        <td>
                            <textarea name='ItemName' style="width:250px; height:40px;"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="BarCode">Barcode</label><br>
                        </td>
                        <td>
                            <textarea name='BarCode' style="width:250px; height:40px;"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="itemcount">Count</label><br>
                        </td>
                        <td>
                            <input name='ItemCount' style="width:50px; height:25px;"></input>
                        </td>
                    </tr>		
                </table>
            </div><br>
            <input name='submit' value='Add' type='submit' style="margin-left: 73px; width:50px;" class="btn btn-primary button"/>
        </form>
    </div>
</body>
</html>