<?php
session_start();
 $_SESSION['admin'] = NULL;
 header('Content-Type: text/html; charset=utf-8');?>

<!DOCTYPE html>

<html>

<head>

    <title>LOGIN</title>

    <link rel="stylesheet" type="text/css" href="css/style2.css">

</head>

<body>



<center>
		<div id="login">
			
			<form id="connect" method="post" action="check_login.php">
				<center><strong>Packet Up</strong></center>
				
				<?php if (isset($_GET['error'])) { ?>
					<p class="error"><?php echo $_GET['error']; ?></p>
				<?php } ?>
				
				<center>
				<table width="100%" border="0" cellpadding="3" cellspacing="1">
					<tr>
						<td colspan="3"></td>
					</tr>
					<tr>
						<td width="78"><label>User Name</label></td>
						<td width="6">:</td>
						<td width="294"><input name="uname" type="text" id="myusername" placeholder="User Name"></td>
					</tr>
					<tr>
						<td><label>Password</label></td>
						<td>:</td>
						<td><input name="password" type="password" id="mypassword" placeholder="Password"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td><input type="submit" name="Submit" value="Login"></td>
					</tr>
				</table></center>
			</form>
		</div>
	</center>
</body>

</html>