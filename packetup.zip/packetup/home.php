
<?php 
session_start();
if($_SESSION['admin'] == NULL) {
		header('Location: http://localhost:8888/packetup/index.php');
	}
	header('Content-Type: text/html; charset=utf-8');
?>
<html>
<head>
    <title>Home</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<script src="jquery/js/bootstrap.js"></script>
	<link rel="stylesheet" type="text/css" href="jquery/css/bootstrap.css"/>
</head>
<body>
<?php
			$nr=0;
			
			include 'top_menu.php';
			
		?>
		
		<div id='body'>
			<H2>Logged in Successfuly as <?php echo $_SESSION['admin'] ?></H2>

		</div>
      

</body>

</html>