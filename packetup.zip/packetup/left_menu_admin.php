<div id='left_meniu'>
    &nbsp; &nbsp;&nbsp;<b>Items management</b><br/>
    <?php 
        if($_SESSION['Lic'][3] == 1 AND $nr == 2) echo "<p><a class='btn btn-primary button' href='logs.php'>Logs</a></p>";
        if($_SESSION['Lic'][3] == 1 AND $nr != 2) echo "<p><a class='btn btn-primary button' href='logs.php'>Logs</a></p>";
        if($_SESSION['Lic'][3] == 1 AND $nr == 2) echo "<p><a class='btn btn-primary button' href='deleted_items.php'>Deleted items</a></p>";
        if($_SESSION['Lic'][3] == 1 AND $nr != 2) echo "<p><a class='btn btn-primary button' href='deleted_items.php'>Deleted items</a></p>";
    ?>
</div>