<?php 
    session_start();
    if($_SESSION['admin'] == NULL) {
        header('Location: http://localhost/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script src="jquery/js/bootstrap.js"></script>
<link rel="stylesheet" type="text/css" href="jquery/css/bootstrap.css"/>
</head>
<body>
    <img src='img/packetup_logo.png' style='padding-left: 50px;'/><br/><br/>
    <?php
        include 'connect.php';
        include 'top_menu.php';
        include 'left_menu.php';
    ?>
    <div id='body'>
        <h2>DELETE ITEM</h2><br><br>
        <form method="post" action="item_delete_do.php">
            <h3>Select item from list to delete</h3>
            <select name="itemas" style="height:32px;"><?php
            include('connect.php');
            $sql = mysqli_query($conn, "SELECT item_name FROM items WHERE status = '1' ORDER BY item_name ASC");
            while ($row = $sql->fetch_assoc()){
                ?>
                <option value="<?php echo $row['item_name']; ?>">
                <?php echo $row['item_name']; ?>
                </option>
                <?php 
            } ?>
            <input type="submit" name="delete" value="Delete Item" onclick="alert('Are you sure you want to delete this item?')" class="btn btn-primary button" style="width: 100px">
        </form>
    </div>	
</body>
</html>


