<?php 
session_start();
$vardas = $_SESSION['admin'];
if($_SESSION['admin'] == NULL) {
		header('Location: http://localhost:8888/packetup/index.php');
	}
	header('Content-Type: text/html; charset=utf-8');
	
$nr = 1;
?>

<script type="text/javascript"> 
			function closeWin()
				{
				link = 'items.php';
				window.location.href = link;
				}
</script>
<?php 
$conn = mysqli_connect("localhost", "mamp", "", "packetup");

$itemname = $_POST['itemas'];
//pasiemu barkoda is change count2
$barkodas = $_POST['barkodas'];

if(isset($_POST['Shipped'])) {
  
$sql = "SELECT item_count FROM items WHERE item_name='$itemname'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $oldcountas = $row["item_count"];
  }    
    
$ItemCountNew = $_POST['ItemCountNew'];
$newcountasshipped = $oldcountas - $_POST['ItemCountNew'];



$query2 = mysqli_query($conn, "UPDATE items SET item_count=item_count-'$ItemCountNew' WHERE item_name = '$itemname'");
$query3 = mysqli_query($conn, "INSERT INTO logs (state, datetime, item, BarCode ,text, user) VALUES ('shipped',CURRENT_TIMESTAMP,'$itemname', '$barkodas' , 'shipped $ItemCountNew out of  $oldcountas. Now left $newcountasshipped', '$vardas' ) ");
echo "Item Count Updated. <SCRIPT LANGUAGE='javascript'>closeWin();</SCRIPT>";



}

if(isset($_POST['Recieved'])) {

    
$sql = "SELECT item_count FROM items WHERE item_name='$itemname'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $oldcountas = $row["item_count"];
}    
    
$ItemCountNew = $_POST['ItemCountNew'];  
$newcountasrecieved = $oldcountas + $_POST['ItemCountNew'];
    
    
    
$query2 = mysqli_query($conn, "UPDATE items SET item_count=item_count+'$ItemCountNew' WHERE item_name = '$itemname'");
$query3 = mysqli_query($conn, "INSERT INTO logs (state, datetime, item, text, user) VALUES ('restock',CURRENT_TIMESTAMP,'$itemname', 'Recieved $ItemCountNew items restock. New count $newcountasrecieved','$vardas')");
echo "Item Count Updated. <SCRIPT LANGUAGE='javascript'>closeWin();</SCRIPT>";

}

?>
