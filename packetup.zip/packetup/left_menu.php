<div id='left_meniu'>
    &nbsp; &nbsp;&nbsp;<b>Items management</b><br/>
    <p><a class="btn btn-primary button" href='items.php'>Item list</a></p>
    
    
    <?php 
        if($_SESSION['Lic'][1] == 1 AND $nr == 1) echo "<p><a class='btn btn-primary button' href='add_item.php'>Add new item</a></p>";
        if($_SESSION['Lic'][1] == 1 AND $nr != 1) echo "<p><a class='btn btn-primary button' href='add_item.php'>Add new item</a></p>";
    
        if($_SESSION['Lic'][1] == 1 AND $nr == 1) echo "<p><a class='btn btn-primary button' href='change_count_v2.php'>Update item count</a></p>";
        if($_SESSION['Lic'][1] == 1 AND $nr != 1) echo "<p><a class='btn btn-primary button' href='change_count_v2.php'>Update item count</a></p>";  
    
        if($_SESSION['Lic'][2] == 1 AND $nr == 1) echo "<p><a class='btn btn-primary button' href='item_delete_v2.php'>Delete existing item</a></p>";
        if($_SESSION['Lic'][2] == 1 AND $nr != 1) echo "<p><a class='btn btn-primary button' href='item_delete_v2.php'>Delete existing item</a></p>";
    
        
    
        if($_SESSION['Lic'][4] == 1 AND $nr == 1) echo "<b>Old shit</b><br/>";
        if($_SESSION['Lic'][4] == 1 AND $nr == 1) echo "<p><a class='btn btn-primary button' href='change_count.php'>Update item count old</a></p>";
        if($_SESSION['Lic'][4] == 1 AND $nr != 1) echo "<p><a class='btn btn-primary button' href='change_count.php'>Update item count old</a></p>";
        if($_SESSION['Lic'][4] == 1 AND $nr == 1) echo "<p><a class='btn btn-primary button' href='item_delete.php'>Delete old</a></p>";
        if($_SESSION['Lic'][4] == 1 AND $nr != 1) echo "<p><a class='btn btn-primary button' href='item_delete.php'>Delete old</a></p>";
    ?>
</div>
