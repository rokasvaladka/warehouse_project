<?php 
    session_start();
    $vardas = $_SESSION['admin'];
    if($_SESSION['admin'] == NULL) {
        header('Location: http://localhost:8888/packetup/index.php');
    }
    header('Content-Type: text/html; charset=utf-8');
    $nr = 1;
?>
<script type="text/javascript"> 
    function closeWin(){
        link = 'items.php';
        window.location.href = link;
    }
</script>
<?php 
    $conn = mysqli_connect("localhost", "mamp", "", "packetup");
    if(isset($_POST['delete'])) {
        $itemname = $_POST['itemas'];
        $query1 = mysqli_query($conn, "UPDATE items SET status=0 WHERE item_name = '$itemname'");
        $query3 = mysqli_query($conn, "INSERT INTO logs (state, datetime, item, text, user) VALUES ('deleted',CURRENT_TIMESTAMP,'$itemname', 'Item was deleted.','$vardas')");
        echo "Item successfully deleted. <SCRIPT LANGUAGE='javascript'>closeWin();</SCRIPT>";
    }
?>
