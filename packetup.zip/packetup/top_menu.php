<?php
    echo "
    <div id='top_men'>
        <nav class='navbar navbar-default'>
        <p class='navbar-text'>Signed in as <b>".$_SESSION['admin']."</b>
        <a href='http://localhost:8888/packetup/index.php' type='button' class='btn btn-danger btn-xs'>
        <span class='glyphicon glyphicon-remove' aria-hidden='true'></span>
        </a>
        </p>
        <div class='collapse navbar-collapse' id='bs-example-navbar-collapse-1'>
            <ul class='nav navbar-nav'>";
            if($_SESSION['Lic'][0] == 1 AND $nr == 1) echo "<li class='active'><a href='http://localhost:8888/packetup/items.php'>Items</a></li>";
            if($_SESSION['Lic'][0] == 1 AND $nr != 1) echo "<li><a href='http://localhost:8888/packetup/items.php'>Items</a></li>";
            if($_SESSION['Lic'][3] == 1 AND $nr == 2) echo "<li class='active'><a href='http://localhost:8888/packetup/admin_panel.php'>Admin</a></li>";
            if($_SESSION['Lic'][3] == 1 AND $nr != 2) echo "<li><a href='http://localhost:8888/packetup/admin_panel.php'>Admin</a></li>";
            echo "			
            </ul>
        </div>
        </nav>
    </div>";
?>
